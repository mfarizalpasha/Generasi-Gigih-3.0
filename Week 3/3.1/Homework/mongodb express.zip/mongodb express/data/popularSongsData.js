const popularSongsData = [
  {
    title: "Stay",
    playCount: 250,
    period: "2023-01-01 - 2023-02-28",
  },
  {
    title: "Montero (Call Me By Your Name)",
    playCount: 180,
    period: "2023-01-01 - 2023-02-28",
  },
  {
    title: "drivers license",
    playCount: 310,
    period: "2023-01-01 - 2023-02-28",
  },
  {
    title: "Bad Habits",
    playCount: 290,
    period: "2023-01-01 - 2023-02-28",
  },
  {
    title: "Happier Than Ever",
    playCount: 200,
    period: "2023-01-01 - 2023-02-28",
  },
  {
    title: "Pelangi di Matamu",
    playCount: 120,
    period: "2023-01-01 - 2023-02-28",
  },
  {
    title: "Menunggu Kamu",
    playCount: 90,
    period: "2023-01-01 - 2023-02-28",
  },
  {
    title: "Rindu Dalam Hati",
    playCount: 80,
    period: "2023-01-01 - 2023-02-28",
  },
  {
    title: "Kasih Tak Sampai",
    playCount: 150,
    period: "2023-01-01 - 2023-02-28",
  },
  {
    title: "Cinta Luar Biasa",
    playCount: 180,
    period: "2023-01-01 - 2023-02-28",
  },
];

module.exports = popularSongsData;
