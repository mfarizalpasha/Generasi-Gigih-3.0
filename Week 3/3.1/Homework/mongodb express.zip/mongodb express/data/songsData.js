const songsData = [
  {
    title: "Shape of You",
    artist: "Ed Sheeran",
    album: "÷ (Divide)",
  },
  {
    title: "Someone Like You",
    artist: "Adele",
    album: "21",
  },
  {
    title: "Uptown Funk",
    artist: "Mark Ronson ft. Bruno Mars",
    album: "Uptown Special",
  },
  {
    title: "Despacito",
    artist: "Luis Fonsi ft. Daddy Yankee",
    album: "Vida",
  },
  {
    title: "Bad Guy",
    artist: "Billie Eilish",
    album: "When We All Fall Asleep, Where Do We Go?",
  },

  {
    title: "Rindu Dalam Hati",
    artist: "Armand Maulana",
    album: "OST. Alexandria",
  },
  {
    title: "Bukti",
    artist: "Virgoun",
    album: "Single",
  },
  {
    title: "Takkan Terganti",
    artist: "Kahitna",
    album: "Soulmate",
  },
  {
    title: "Cinta Luar Biasa",
    artist: "Andmesh Kamaleng",
    album: "Cinta Luar Biasa",
  },
  {
    title: "Mantan Terindah",
    artist: "Raisa",
    album: "Handmade",
  },
];

module.exports = songsData;
