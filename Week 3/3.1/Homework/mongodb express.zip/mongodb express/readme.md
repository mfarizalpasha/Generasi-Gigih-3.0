Database "music_database"

SONG
a. "/song" // Menampilkan data song yang ada pada database
![Alt text](img/image.png)

Database :
![Alt text](img/image-1.png)

b. "/song/add" // Menambahkan data pada database berdasarkan songsData.js
![Alt text](img/image-2.png)

Database :
![Alt text](img/image-3.png) // Data berjumlah 10

c. "/song/delete" // Menghapus semua data pada database
![Alt text](img/image-4.png)

Database :
![Alt text](img/image-1.png)

Hal yang sama juga berlaku pada playlist dan artist
